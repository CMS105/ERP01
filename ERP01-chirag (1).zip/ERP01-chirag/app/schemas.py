from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, EmailStr, ConfigDict
from app.models import (
    UserRole, BookingStatus, DeliveryOutcome, PaymentStatus,
    PaymentMethod, CylinderStatus, FindingReviewStatus, FindingSeverity,
    SupportTicketStatus, DeliveryRequestStatus
)

class Token(BaseModel):
    access_token: str
    token_type: str
    role: UserRole
    user_id: int
    full_name: str

class TokenData(BaseModel):
    user_id: Optional[int] = None
    role: Optional[UserRole] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class CustomerRegisterRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    consumer_number: str
    address: str
    city: str
    pincode: str
    connection_type: Optional[str] = "14.2kg Domestic"

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    role: UserRole
    employee_code: Optional[str] = None
    vehicle_number: Optional[str] = None
    assigned_hub_zone: Optional[str] = None

class UserStatusUpdate(BaseModel):
    is_active: bool

class CustomerProfileUpdate(BaseModel):
    address: Optional[str] = None
    city: Optional[str] = None
    pincode: Optional[str] = None
    phone: Optional[str] = None

class CustomerProfileOut(BaseModel):
    id: int
    user_id: int
    consumer_number: str
    address: str
    city: str
    pincode: str
    cylinder_quota_limit: int
    quota_used_this_year: int
    connection_type: str

    model_config = ConfigDict(from_attributes=True)

class StaffProfileOut(BaseModel):
    id: int
    user_id: int
    employee_code: str
    vehicle_number: str
    assigned_hub_zone: str
    is_on_duty: bool

    model_config = ConfigDict(from_attributes=True)

class UserOut(BaseModel):
    id: int
    email: str
    full_name: str
    phone: str
    role: UserRole
    is_active: bool
    created_at: datetime
    customer_profile: Optional[CustomerProfileOut] = None
    staff_profile: Optional[StaffProfileOut] = None

    model_config = ConfigDict(from_attributes=True)

class CylinderInventoryCreate(BaseModel):
    serial_number: str
    cylinder_type: str = "14.2kg"
    status: CylinderStatus = CylinderStatus.IN_STOCK
    batch_code: str

class CylinderInventoryUpdate(BaseModel):
    status: Optional[CylinderStatus] = None
    batch_code: Optional[str] = None

class CylinderInventoryOut(BaseModel):
    id: int
    serial_number: str
    cylinder_type: str
    status: CylinderStatus
    batch_code: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class BookingCreate(BaseModel):
    cylinder_type: str = "14.2kg"
    quantity: int = 1
    scheduled_date: str
    idempotency_key: Optional[str] = None

class PaymentRecordOut(BaseModel):
    id: int
    booking_id: int
    customer_id: int
    delivery_boy_id: Optional[int] = None
    amount: float
    payment_method: PaymentMethod
    payment_status: PaymentStatus
    transaction_reference: Optional[str] = None
    collected_at: Optional[datetime] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class DeliveryExecutionOut(BaseModel):
    id: int
    assignment_id: int
    booking_id: int
    delivery_boy_id: int
    outcome: DeliveryOutcome
    outcome_timestamp: datetime
    offline_sync_id: Optional[str] = None
    synced_at: datetime
    empty_cylinder_returned_serial: Optional[str] = None
    failure_reason: Optional[str] = None
    transaction_reference: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class DeliveryAssignmentOut(BaseModel):
    id: int
    booking_id: int
    delivery_boy_id: int
    cylinder_id: Optional[int] = None
    assigned_at: datetime
    status: str
    notes: Optional[str] = None
    execution: Optional[DeliveryExecutionOut] = None

    model_config = ConfigDict(from_attributes=True)

class BookingOut(BaseModel):
    id: int
    booking_number: str
    idempotency_key: Optional[str] = None
    customer_id: int
    cylinder_type: str
    quantity: int
    unit_price: float
    total_amount: float
    subsidy_amount: float
    net_payable: float
    status: BookingStatus
    scheduled_date: str
    created_at: datetime
    assignment: Optional[DeliveryAssignmentOut] = None
    payment: Optional[PaymentRecordOut] = None

    model_config = ConfigDict(from_attributes=True)

class VehicleRecommendationRequest(BaseModel):
    zone_or_route: str
    total_cylinders: int
    delivery_count: int
    area_sq_km: Optional[float] = 10.0
    has_narrow_access: Optional[bool] = False
    has_coordinates: Optional[bool] = True

class VehicleRecommendationOut(BaseModel):
    zone_or_route: str
    recommended_vehicle: str
    vehicle_capacity: int
    density_score: float
    trips_required: int
    explanation: str
    can_auto_dispatch: bool

    model_config = ConfigDict(from_attributes=True)

class BookingAssignRequest(BaseModel):
    delivery_boy_id: int
    cylinder_id: Optional[int] = None
    notes: Optional[str] = None

class DeliveryOutcomeRequest(BaseModel):
    outcome: DeliveryOutcome
    empty_cylinder_returned_serial: Optional[str] = None
    customer_signature_data: Optional[str] = None
    failure_reason: Optional[str] = None
    offline_sync_id: Optional[str] = None

class PaymentCollectRequest(BaseModel):
    amount: float
    payment_method: PaymentMethod
    transaction_reference: Optional[str] = None

class OfflineSyncOutcomeItem(BaseModel):
    offline_sync_id: str
    assignment_id: int
    outcome: DeliveryOutcome
    outcome_timestamp: datetime
    empty_cylinder_returned_serial: Optional[str] = None
    failure_reason: Optional[str] = None
    customer_signature_data: Optional[str] = None

class OfflineSyncPaymentItem(BaseModel):
    booking_id: int
    amount: float
    payment_method: PaymentMethod
    transaction_reference: Optional[str] = None
    collected_at: datetime

class OfflineSyncBatchRequest(BaseModel):
    outcomes: List[OfflineSyncOutcomeItem] = []
    payments: List[OfflineSyncPaymentItem] = []

class OfflineSyncBatchResponse(BaseModel):
    synced_outcomes_count: int
    synced_payments_count: int
    errors: List[str] = []

class FinancialCorrectionRequest(BaseModel):
    payment_id: int
    corrected_amount: float
    reason: str
    audit_notes: str

class FinancialCorrectionOut(BaseModel):
    id: int
    payment_id: int
    booking_id: int
    corrected_by_user_id: int
    original_amount: float
    corrected_amount: float
    reason: str
    audit_notes: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class AuditLogOut(BaseModel):
    id: int
    user_id: Optional[int] = None
    user_role: str
    action: str
    resource_type: str
    resource_id: str
    details: str
    timestamp: datetime

    model_config = ConfigDict(from_attributes=True)

class ReconciliationReportItem(BaseModel):
    booking_id: int
    booking_number: str
    customer_id: int
    booking_status: str
    delivery_status: Optional[str] = None
    delivery_outcome: Optional[str] = None
    payment_status: Optional[str] = None
    expected_amount: float
    collected_amount: Optional[float] = None
    is_reconciled: bool
    notes: str

class DiscrepancyReportItem(BaseModel):
    issue_type: str
    booking_id: Optional[int] = None
    customer_id: Optional[int] = None
    delivery_boy_id: Optional[int] = None
    details: str
    severity: str

class FinancialSummaryOut(BaseModel):
    total_bookings: int
    total_sales_value: float
    total_collected_amount: float
    total_pending_amount: float
    collections_by_method: dict
    total_corrections_count: int
    net_correction_variance: float

class ReconciliationRunOut(BaseModel):
    id: int
    run_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str
    triggered_by_user_id: Optional[int] = None
    records_examined: int
    findings_count: int
    summary_json: Optional[str] = None
    error_message: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class ReconciliationFindingOut(BaseModel):
    id: int
    finding_id: str
    run_id: str
    rule_code: str
    severity: str
    affected_table: str
    affected_record_id: str
    explanation: str
    detected_at: datetime
    review_status: str
    reviewed_by_user_id: Optional[int] = None
    reviewed_at: Optional[datetime] = None
    review_reason: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class FindingReviewRequest(BaseModel):
    review_status: FindingReviewStatus
    reason: str

class PaginatedFindingsOut(BaseModel):
    total: int
    page: int
    limit: int
    items: List[ReconciliationFindingOut]

class ReconciliationSummaryOut(BaseModel):
    total_runs: int
    last_run_at: Optional[datetime] = None
    last_run_status: Optional[str] = None
    total_findings: int
    pending_findings: int
    reviewed_findings: int
    resolved_findings: int
    dismissed_findings: int
    by_rule: Dict[str, int]
    by_severity: Dict[str, int]

class SupportMessageCreate(BaseModel):
    message: str

class SupportMessageOut(BaseModel):
    id: int
    ticket_id: int
    sender_id: Optional[int] = None
    message: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class SupportTicketCreate(BaseModel):
    category: str
    description: str
    booking_id: Optional[int] = None
    transaction_id: Optional[str] = None
    priority: Optional[str] = "NORMAL"
    language: str = "English"
    offline_sync_id: Optional[str] = None

class SupportTicketEscalate(BaseModel):
    escalation_reason: str

class SupportTicketOut(BaseModel):
    id: int
    ticket_number: str
    customer_id: int
    booking_id: Optional[int] = None
    transaction_id: Optional[str] = None
    category: str
    description: str
    priority: str = "NORMAL"
    language: str
    status: SupportTicketStatus
    ai_response: Optional[str] = None
    escalation_reason: Optional[str] = None
    resolution_notes: Optional[str] = None
    conversation_context: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    assigned_staff_id: Optional[int] = None
    messages: List[SupportMessageOut] = []

    model_config = ConfigDict(from_attributes=True)

class TicketUpdateAdmin(BaseModel):
    status: Optional[SupportTicketStatus] = None
    priority: Optional[str] = None
    assigned_staff_id: Optional[int] = None
    resolution_notes: Optional[str] = None

class TicketAssignAdmin(BaseModel):
    staff_user_id: int
    notes: Optional[str] = None

class ChatbotMessageRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    language: Optional[str] = "English"

class ChatbotMessageResponse(BaseModel):
    session_id: str
    response: str
    assistant_message: Optional[str] = None
    resolution_state: str  # "UNRESOLVED", "PROPOSED", "RESOLVED", "ESCALATED"
    escalation_state: str = "NONE"  # "NONE", "SUGGESTED", "ESCALATED"
    escalated: bool = False
    requires_confirmation: bool = False
    ticket_id: Optional[Union[str, int]] = None
    ticket_number: Optional[str] = None
    ticket_status: Optional[str] = None
    priority: Optional[str] = None
    suggested_actions: List[str] = []
    is_safety_emergency: bool = False

    model_config = ConfigDict(from_attributes=True)

class ChatMessageOut(BaseModel):
    id: int
    sender_role: str
    message: str
    metadata_json: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class ChatSessionHistoryOut(BaseModel):
    session_id: str
    customer_id: int
    status: str
    unresolved_attempts: int
    associated_ticket_id: Optional[int] = None
    ticket_number: Optional[str] = None
    messages: List[ChatMessageOut] = []

    model_config = ConfigDict(from_attributes=True)

class DeliveryConfirmationCreate(BaseModel):
    assignment_id: Optional[int] = None
    booking_id: Optional[int] = None
    cylinder_serial: Optional[str] = None
    notes: Optional[str] = None

class DeliveryRejectRequest(BaseModel):
    rejection_reason: Optional[str] = "Customer rejected delivery"

class DeliveryConfirmationRequestOut(BaseModel):
    id: int
    request_id: str
    booking_id: int
    booking_number: Optional[str] = None
    customer_id: int
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_address: Optional[str] = None
    delivery_partner_id: int
    delivery_partner_name: Optional[str] = None
    delivery_partner_phone: Optional[str] = None
    assignment_id: int
    amount_due: float
    cylinder_serial: Optional[str] = None
    cylinder_type: str
    status: str
    rejection_reason: Optional[str] = None
    notes: Optional[str] = None
    transaction_reference: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)

class DeliveryTransactionOut(BaseModel):
    id: int
    transaction_reference: str
    confirmation_request_id: int
    request_id: Optional[str] = None
    booking_id: int
    booking_number: Optional[str] = None
    customer_id: int
    customer_name: Optional[str] = None
    delivery_partner_id: int
    delivery_partner_name: Optional[str] = None
    assignment_id: int
    delivery_execution_id: Optional[int] = None
    payment_record_id: Optional[int] = None
    amount: float
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


